Changelog
=========

v1.0.2
------

- Fix issue when sending enrolment message

v1.0.1
------

- Implement privacy API (GDPR compliance)

v1.0.0
------

- Initial release
