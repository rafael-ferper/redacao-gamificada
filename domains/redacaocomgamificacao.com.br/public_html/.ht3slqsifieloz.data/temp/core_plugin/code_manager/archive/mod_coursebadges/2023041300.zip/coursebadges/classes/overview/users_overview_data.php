<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Users_overview_data file.
 *
 * @package     mod_coursebadges
 * @copyright   2020 DNE - Ministere de l'Education Nationale 
 * @license     http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
namespace mod_coursebadges\overview;

use mod_coursebadges\overview\utils;

require_once($CFG->dirroot.'/lib/badgeslib.php');

/**
 * Class users_overview_data.
 *
 * Library of functions for ussers overview.
 *
 * @package     mod_coursebadges
 * @copyright   2020 DNE - Ministere de l'Education Nationale 
 * @license     http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class users_overview_data {

    private $cmid;
    private $cm;
    private $courseid;
    private $startindex;
    private $endindex;
    private $sortorder;

    private $data;
    private $resultcount;
    private $badgeid;
    private $coursebadges_id;
    private $groupid;
    private $status;
    private $username;

    const ALL_BADGES = -1;
    const EARNED_BADGES = 0;
    const SELECTED_BADGES = 1;


    public function __construct($cmid, $courseid, $startindex, $endindex, $sortorder) {
        $this->cmid = $cmid;
        $this->courseid = $courseid;
        $this->cm = $this->get_coursemodule_by_instanceid();
        $this->startindex = $startindex;
        $this->endindex = $endindex;
        $this->sortorder = $sortorder;

        $this->data = [];
        $this->resultcount = 0;

        $this->badgeid = 0;
        $this->coursebadges_id = 0;
        $this->groupid = 0;
        $this->status = self::ALL_BADGES;
        $this->username = [];

    }

    public function execute_sql() {
        global $DB, $USER;

        $whereclauses = [];
        $params = [];

        $wheresqlselectedbadges = '';
        $wheresqlearnedbadges = '';
        if($this->badgeid){
            $whereclauses[] = '(users.selectedbadgeids=:badgeid1 OR users.earnedbadgeids=:badgeid2)';

            $params['badgeid1'] = $this->badgeid;
            $params['badgeid2'] = $this->badgeid;
        }

        if(count($this->username)){
            $c = [];

            foreach($this->username as $s){
                $c[] = 'users.lastname LIKE "%'.$s.'%"';
                $c[] = 'users.firstname LIKE "%'.$s.'%"';
            }

            $whereclauses[] = '('.implode(' OR ', $c).')';
        }

        $context = \context_module::instance($this->cmid);

        if($this->groupid){
            $whereclauses[] = 'users.groupids=:groupid';
            $params['groupid'] = $this->groupid;
        } else if(groups_get_activity_groupmode($this->cm) == SEPARATEGROUPS
            && !has_capability('moodle/site:accessallgroups', $context)){
            if($allowedgroups = groups_get_all_groups($this->cm->course, $USER->id, $this->cm->groupingid, 'g.id')){
                $allowedgroupids = array_keys($allowedgroups);
                if(count($allowedgroups > 1)){
                    $whereclausegroup = [];
                    foreach ($allowedgroupids as $allowedgroupid){
                        $whereclausegroup[] = 'users.groupids = '.$allowedgroupid;
                    }
                    $whereclauses[] = '('.implode($whereclausegroup, ' OR ').')';
                } else {
                    $allowedgroupids = implode(", ", $allowedgroupids);
                    $whereclauses[] = 'users.groupids = :groupids';
                    $params['groupids'] = $allowedgroupids;
                }
            }
        }

        if($this->status == self::EARNED_BADGES){
            // desactivate the sql part of the selected badges with a false condition
            $wheresqlselectedbadges .= ' AND 1=0';
        }

        if($this->status == self::SELECTED_BADGES){
            // desactivate the sql part of the earned badges with a false condition
            $wheresqlearnedbadges .= ' AND 1=0';
        }

        $wheresql = '';
        if(count($whereclauses)){
            $wheresql = 'WHERE ';
            $wheresql .= implode(' AND ', $whereclauses);
        }

        $params['cmid1'] = $this->cmid;
        $params['cmid2'] = $this->cmid;

        $sqlFrom = ' FROM (
            SELECT 
                u.id,
                u.lastname,
                u.firstname,
            
                groups.id groupids,
                groups.name groupnames,
                
                '.$this->sql_cast_null_to_bigint().' selectedbadgeids,
                NULL selectedbadgenames,
                NULL selectedmodnames,
                '.$this->sql_cast_null_to_bigint().' selectedmodid,
            
                '.$this->sql_cast_null_to_bigint().' earnedbadgeids,
                NULL earnedbadgenames
            FROM {user} u
            INNER JOIN {user_enrolments} ue ON ue.userid=u.id
            INNER JOIN {enrol} e ON e.id=ue.enrolid
            LEFT JOIN (
                SELECT g.id, g.courseid, g.name, gm.userid
                FROM {groups_members} gm
                INNER JOIN {groups} g ON g.id=gm.groupid
            ) groups ON (groups.userid=u.id AND groups.courseid=e.courseid)
            WHERE e.courseid=:courseid1
        UNION
            SELECT 
                u.id,
                u.lastname,
                u.firstname,
        
                groups.id groupids,
                groups.name groupnames,
                
                csb.badgeid selectedbadgeids,
                b.name selectedbadgenames,
                cb.name selectedmodnames,
                cb.id selectedmodid,
        
                '.$this->sql_cast_null_to_bigint().' earnedbadgeids,
                NULL earnedbadgenames
            FROM {enrol} e
            INNER JOIN {user_enrolments} ue ON ue.enrolid=e.id
            INNER JOIN {user} u ON u.id=ue.userid
            INNER JOIN {coursebadges_usr_select_bdg} cuc ON cuc.userid=u.id
            INNER JOIN {coursebadges_available_bdg} csb ON csb.id=cuc.selectionbadgeid
            INNER JOIN {coursebadges} cb ON cb.id=csb.coursebadgeid
            INNER JOIN {course_modules} cm ON cm.instance=cb.id
            INNER JOIN {badge} b ON b.id=csb.badgeid
            LEFT JOIN {badge_issued} bi ON (bi.badgeid=b.id AND bi.userid=u.id)
            LEFT JOIN (
                SELECT g.id, g.courseid, g.name, gm.userid
                FROM {groups_members} gm
                INNER JOIN {groups} g ON g.id=gm.groupid
            ) groups ON (groups.userid=u.id AND groups.courseid=e.courseid)
            WHERE e.courseid=:courseid2 AND bi.id IS NULL 
            AND cm.module=(SELECT id FROM {modules} WHERE name = :name1) AND cm.id=:cmid1'.$wheresqlselectedbadges.'
        UNION
            SELECT 
                u.id,
                u.lastname,
                u.firstname,
        
                groups.id groupids,
                groups.name groupnames,
                
                '.$this->sql_cast_null_to_bigint().' selectedbadgeids,
                NULL selectedbadgenames,
                NULL selectedmodnames,
                '.$this->sql_cast_null_to_bigint().' selectedmodid,
                
                csb.badgeid earnedbadgeids,
                b.name earnedbadgenames
            FROM {enrol} e
            INNER JOIN {user_enrolments} ue ON ue.enrolid=e.id
            INNER JOIN {user} u ON u.id=ue.userid
            INNER JOIN {coursebadges_usr_select_bdg} cuc ON cuc.userid=u.id
            INNER JOIN {coursebadges_available_bdg} csb ON csb.id=cuc.selectionbadgeid
            INNER JOIN {coursebadges} cb ON cb.id=csb.coursebadgeid
            INNER JOIN {course_modules} cm ON cm.instance=cb.id
            INNER JOIN {badge} b ON b.id=csb.badgeid
            INNER JOIN {badge_issued} bi ON bi.badgeid=b.id
            LEFT JOIN (
                SELECT g.id, g.courseid, g.name, gm.userid
                FROM {groups_members} gm
                INNER JOIN {groups} g ON g.id=gm.groupid
            ) groups ON (groups.userid=u.id AND groups.courseid=e.courseid)
            WHERE e.courseid=:courseid3 AND bi.userid=u.id
            AND cm.module=(SELECT id FROM {modules} WHERE name = :name2) AND cm.id=:cmid2'.$wheresqlearnedbadges.'
        ) users ';

        $sqlCount = 'SELECT COUNT(*) as nbtotal '.$sqlFrom.$wheresql;        
        $sql = '
SELECT
    users.id,
	users.lastname,
	users.firstname,

	'.$this->sql_group_concat('DISTINCT '.$this->sql_cast_to_char('users.groupids')).' groupids,
	'.$this->sql_group_concat('DISTINCT users.groupnames',',', 'users.groupnames ASC').' groupnames,

	'.$this->sql_group_concat('DISTINCT '.$this->sql_cast_to_char('users.selectedbadgeids'),',', $this->sql_cast_to_char('users.selectedbadgeids').' ASC').' selectedbadgeids,
	'.$this->sql_group_concat('DISTINCT users.selectedbadgenames').' selectedbadgenames,
	
	COUNT(DISTINCT users.selectedbadgeids) selectedbadgescount,

    '.$this->sql_group_concat('DISTINCT '.$this->sql_cast_to_char('users.earnedbadgeids'),',', $this->sql_cast_to_char('users.earnedbadgeids').' ASC').' earnedbadgeids ,
	'.$this->sql_group_concat('DISTINCT users.earnedbadgenames').' earnedbadgenames,
	
	COUNT(DISTINCT users.earnedbadgeids) earnedbadgescount,
	COALESCE((COUNT(DISTINCT users.earnedbadgeids)/NULLIF(COUNT(DISTINCT users.selectedbadgeids)+COUNT(DISTINCT users.earnedbadgeids), 0)), 0) percent
	

'.$sqlFrom.$wheresql.'
GROUP BY users.id, users.lastname, users.firstname
ORDER BY '.$this->sortorder;

        $params['courseid1'] = $this->courseid;
        $params['courseid2'] = $this->courseid;
        $params['courseid3'] = $this->courseid;
        $params['name1'] = "coursebadges";
        $params['name2'] = "coursebadges";

        $results = $DB->get_records_sql($sql, $params, $this->startindex, $this->endindex);

        
        $this->resultcount = $DB->get_record_sql($sqlCount, $params)->nbtotal;

        $results = $this->process_results($results);

        return $results;
    }

    public function set_badgeid($badgeid) {
        $this->badgeid = $badgeid;
    }

    public function set_coursebadges_id($coursebadges_id) {
        $this->coursebadges_id = $coursebadges_id;
    }

    public function set_groupid($groupid) {
        $this->groupid = $groupid;
    }

    public function set_status($status) {
        if(!in_array($status, [self::SELECTED_BADGES, self::EARNED_BADGES])){
            return;
        }

        $this->status = $status;
    }

    public function set_username($username){
        $username = trim($username);

        $this->username = explode(' ', $username);
    }

    private function get_coursemodule_by_instanceid() {
        return get_coursemodule_from_id('coursebadges', $this->cmid, $this->courseid);
    }

    private function process_results($results) {
        $context = \context_course::instance($this->courseid);
        $contextid = $context->id;
        
        $processedResults = [];

        foreach($results as $user)
        {
            $user->earnedbadgeids = ($user->earnedbadgeids ? explode(',', $user->earnedbadgeids) : []);
            $user->selectedbadgeids = ($user->selectedbadgeids ? explode(',', $user->selectedbadgeids) : []);

            $pu = new \stdClass();
            $pu->firstname = $user->firstname;
            $pu->lastname = $user->lastname;

            $pu->earnedbadges = [];
            $pu->selectedbadges = [];
            foreach($user->earnedbadgeids as $bid){
                $earnedBadge = new \stdClass();
                $earnedBadge->img_url = utils::get_img_url_badge($bid, $contextid)->out(false);
                if (has_capability('moodle/badges:viewbadges', $context)) {
                    $earnedBadge->badge_url = utils::get_url_badge($bid)->out(false);
                }
                $pu->earnedbadges[] = $earnedBadge;
                $pu->selectedbadges[] = $earnedBadge;
            }

            
            foreach($user->selectedbadgeids as $bid){
                $selectedBadge = new \stdClass();
                $selectedBadge->img_url = utils::get_img_url_badge($bid, $contextid)->out(false);
                if (has_capability('moodle/badges:viewbadges', $context)) {
                    $selectedBadge->badge_url = utils::get_url_badge($bid)->out(false);
                }
                $pu->selectedbadges[] = $selectedBadge;
            }

            $pu->badgeearnedcount = $user->earnedbadgescount;
            $pu->badgetotal = (count($user->selectedbadgeids) + count($user->earnedbadgeids));
            $pu->badgepercent = 0;
            if($pu->badgetotal){
                $pu->badgepercent = ceil($pu->badgeearnedcount/$pu->badgetotal*100);
            }

            $user->groupnames = ($user->groupnames ? explode(',', $user->groupnames) : []);
            $pu->groupnames = [];
            foreach($user->groupnames as $group){
                $g = new \stdClass();
                $g->name = $group;
                $pu->groupnames[] = $g;
            }

            $processedResults[] = $pu;
        }

        return $processedResults;
    }

    public function get_result_count() {
        return $this->resultcount;
    }

    public static function get_jtable_columns() {
        return [
            'id' => [
                'key' => true,
                'create' => false,
                'edit' => false,
                'list' => false,
                'sorting' => false,
            ],
            'lastname' => [
                'title' => get_string('lastnamecolumn', 'mod_coursebadges'),
                'key' => false,
                'create' => false,
                'edit' => false,
                'list' => true,
                'sorting' => true,
            ],
            'firstname' => [
                'title' => get_string('firstnamecolumn', 'mod_coursebadges'),
                'key' => false,
                'create' => false,
                'edit' => false,
                'list' => true,
                'sorting' => true,
            ],
            'groupnames' => [
                'title' => get_string('groupnamecolumn', 'mod_coursebadges'),
                'key' => false,
                'create' => false,
                'edit' => false,
                'list' => true,
                'sorting' => true,
            ],
            'earnedbadges' => [
                'title' => get_string('earnedbadgescolumn', 'mod_coursebadges'),
                'key' => false,
                'create' => false,
                'edit' => false,
                'list' => true,
                'sorting' => false,
            ],
            'selectedbadges' => [
                'title' => get_string('selectedbadgescolumn', 'mod_coursebadges'),
                'key' => false,
                'create' => false,
                'edit' => false,
                'list' => true,
                'sorting' => false,
            ],
            'percent' => [
                'title' => get_string('percentcolumn', 'mod_coursebadges'),
                'key' => false,
                'create' => false,
                'edit' => false,
                'list' => true,
                'sorting' => true,
            ]
        ];
    }

    // for compatibility with moodle < 3.11
    private function sql_group_concat(string $field, string $separator = ', ', string $sort = '') {
        global $DB;
        $dbfamily = $DB->get_dbfamily();
        if ($dbfamily == 'postgres') {
            $fieldsort = $sort ? "ORDER BY {$sort}" : '';
            return "STRING_AGG($field, '{$separator}' {$fieldsort})";
        } else if ($dbfamily == 'oracle') {
            $fieldsort = $sort ?: '1';
            return "LISTAGG({$field}, '{$separator}') WITHIN GROUP (ORDER BY {$fieldsort})";
        } else if ($dbfamily == 'mssql') {
            $fieldsort = $sort ? "WITHIN GROUP (ORDER BY {$sort})" : '';
            return "STRING_AGG({$field}, '{$separator}') {$fieldsort}";
        } else {
            $fieldsort = $sort ? "ORDER BY {$sort}" : '';
            return "GROUP_CONCAT({$field} {$fieldsort} SEPARATOR '{$separator}')";
        } 
    }

    // for compatibility with moodle < 4.1
    private function sql_cast_to_char(string $field) {
        global $DB;

        $dbfamily = $DB->get_dbfamily();
        if ($dbfamily == 'postgres') {
            return "CAST({$field} AS VARCHAR)";
        } else if ($dbfamily == 'oracle') {
            return "TO_CHAR({$field})";
        }
        return $DB->sql_concat("''", $field);
    }

    private function sql_cast_null_to_bigint() {
        global $DB;

        $dbfamily = $DB->get_dbfamily();
        if ($dbfamily == 'postgres') {
            return 'CAST(NULL AS bigint)';
        }
        return 'NULL';
    }
}